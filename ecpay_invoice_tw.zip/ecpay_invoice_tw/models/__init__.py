from . import account_invoice
from . import res_config_settings
from . import uniform_invoice
from . import sale_order
